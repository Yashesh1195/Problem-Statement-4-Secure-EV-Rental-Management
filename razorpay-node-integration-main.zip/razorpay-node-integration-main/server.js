const express = require('express');
const cors = require('cors');
const Razorpay = require('razorpay');
const crypto = require('crypto');
const path = require('path');

const app = express();

// Middleware with more specific CORS options
app.use(cors({
    origin: 'http://localhost:3000',
    methods: ['GET', 'POST'],
    credentials: true
}));
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// Initialize Razorpay
const razorpay = new Razorpay({
    key_id: 'rzp_test_3qxM9mXAeaCFK0', // Your Razorpay Key ID
    key_secret: 'CMALIVnb1IBgUCVx6ilrPMrW' // Replace with your secret key
});

// Create order endpoint
app.post('/create-order', async (req, res) => {
    try {
        const options = {
            amount: Number(req.body.amount * 100),
            currency: 'INR',
            receipt: 'receipt_' + Date.now()
        };

        const order = await razorpay.orders.create(options);
        res.json(order);
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ error: error.message });
    }
});

// Verify payment endpoint
app.post('/verify-payment', (req, res) => {
    try {
        console.log('Received verification request:', req.body); // Debug log

        const {
            razorpay_order_id,
            razorpay_payment_id,
            razorpay_signature
        } = req.body;

        if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
            console.log('Missing parameters:', { razorpay_order_id, razorpay_payment_id, razorpay_signature });
            return res.status(400).json({
                status: 'failed',
                error: 'Missing required parameters'
            });
        }

        const sign = razorpay_order_id + "|" + razorpay_payment_id;
        const expectedSign = crypto
            .createHmac("sha256", 'CMALIVnb1IBgUCVx6ilrPMrW')
            .update(sign.toString())
            .digest("hex");

        console.log('Signature comparison:', {
            received: razorpay_signature,
            expected: expectedSign
        });

        if (razorpay_signature === expectedSign) {
            return res.json({ status: 'ok' });
        } else {
            return res.status(400).json({
                status: 'failed',
                error: 'Invalid signature'
            });
        }
    } catch (error) {
        console.error('Server verification error:', error);
        return res.status(500).json({
            status: 'error',
            error: error.message
        });
    }
});

// Serve success page
app.get('/payment-success', (req, res) => {
    res.sendFile(path.join(__dirname, 'success.html'));
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});