async function payNow() {
    try {
        const amount = document.getElementById('amount').value;
        if (!amount || amount <= 0) {
            alert("Please enter a valid amount.");
            return;
        }

        const response = await fetch('http://localhost:3000/create-order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ amount })
        });

        if (!response.ok) {
            throw new Error("Failed to create order");
        }

        const order = await response.json();
        console.log("Order created:", order);

        const options = {
            key: "rzp_test_3qxM9mXAeaCFK0",
            amount: order.amount,
            currency: order.currency,
            name: "NextGen EV",
            description: "Test Transaction",
            order_id: order.id,
            handler: async function (response) {
                console.log("Payment response:", response);

                try {
                    const verifyResponse = await fetch('http://localhost:3000/verify-payment', {
                        method: 'POST',
                        headers: { 
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            razorpay_order_id: response.razorpay_order_id,
                            razorpay_payment_id: response.razorpay_payment_id,
                            razorpay_signature: response.razorpay_signature
                        })
                    });

                    const data = await verifyResponse.json();
                    console.log("Verification response:", data);

                    if (data.status === 'ok') {
                        alert('Payment successful!');
                        window.location.href = '/payment-success';
                    } else {
                        throw new Error(data.error || 'Payment verification failed');
                    }
                } catch (error) {
                    console.error("Verification Error:", error);
                    alert(`Error verifying payment: ${error.message}`);
                }
            },
            prefill: {
                name: "NextGen EV",
                email: "het8852@gmail.com",
                contact: "8160641056"
            },
            theme: { color: "#F37254" }
        };

        const rzp = new Razorpay(options);
        rzp.open();

    } catch (error) {
        console.error("Payment Error:", error);
        alert(`Payment Error: ${error.message}`);
    }
}

// ...existing code...